package main.java.com.oneshotmc.tntplus.exceptions;

public class NotEnoughTnt extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = -8148473445604545121L;
	public NotEnoughTnt(){}
	public NotEnoughTnt(String message){
		super(message);
	}
}
