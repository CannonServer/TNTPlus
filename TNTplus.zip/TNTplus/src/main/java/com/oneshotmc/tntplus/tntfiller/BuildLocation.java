package main.java.com.oneshotmc.tntplus.tntfiller;
import org.bukkit.entity.Player;

import com.intellectualcrafters.plot.api.PlotAPI;
public class BuildLocation {
	PlotAPI aPlot = new PlotAPI();
	
	public boolean buildTrue(Player player, int x,int y,int z){
		return true;
	}
}
